# National Parks Service (NPS) Water Balance  
